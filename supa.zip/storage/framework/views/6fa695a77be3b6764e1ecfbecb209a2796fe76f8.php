<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('/med/ca3.jpg')); ?>" width="100%" height="500px" alt="" style="z-index: 1;position: relative">

    <div class="container" style="margin: 3%;">

        <div class="card-columns">

            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card wow fadeInUp slow">
                    <a href="<?php echo e(route('enproduct.single',['slug' => $pro->slug])); ?>" class="text-decoration-none"><img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title"><?php echo e($pro->entitle); ?></h5>
                            <p class="card-text"><?php echo str_limit($pro->endescription,30); ?></p>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.En.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SETUPPROG\WampServer.3.1.9.x64\www\supa\resources\views/frontend/En/projects/proj.blade.php ENDPATH**/ ?>