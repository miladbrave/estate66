<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('/med/pr1.jpg')); ?>" width="100%" height="500px" alt="" style="z-index: 1;position: relative">

    <div class="container" style="margin: 3%;">
        <h4 style="text-align: center;margin: 3%" class="font-weight-bold">سرمایه گذاری</h4>

        <div class="card-columns">

            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card wow fadeInUp slow">
                    <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>" class="text-decoration-none"><img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top"
                                                                 alt="...">
                        <div class="card-body ">
                            <h5 class="card-title"><?php echo e($pro->title); ?></h5>
                            <p class="card-text">This is a longer card with supporting text below as a natural lead-in
                                to
                                additional content. This content is a little bit longer.</p>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/proj.blade.php ENDPATH**/ ?>