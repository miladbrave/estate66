<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('/med/s1.jpg')); ?>" width="100%" height="350px" alt="" style="z-index: 1;position: relative">
    <div class="ser1">
        <div class="container" style="background-color: #f2f2e7">
            <div class="row">
                <div class="col-md-5">
                    <img src="<?php echo e(asset('/med/logo.png')); ?>" width="65%" height="auto" alt="" style="z-index: 1;position: relative"><br>
                </div>
                <div class="col-md-6">
                    <h5>The buying process from start to finish</h5>

                    <h6>Travel to Turkey and visit homes</h6>
                    <p>Let us know when you arrive in Turkey after getting the necessary information and preparing your trip to Turkey. Our staff will welcome you to the airport and will provide you with a 5 star hotel. Your 4 day stay at the hotel will be paid for by us and after a day of rest the home visiting process begins.</p>

                    <h6>Money transfer and document receipt</h6>
                    <p>After choosing your preferred home, we will transfer your money (if you need it) from Iran to you. After completing and transferring your money, getting your home document will be done in just one business day.</p>

                    <h6>Water, electricity, gas and home appliances</h6>
                    <p>The day after you receive the document, the process of registering and registering your water, electricity, gas house and your name will begin with our staff. This phase takes one to three days. Also, if you decide to buy home appliances, our staff will assist you.</p>

                    <h6>Taking the time and preparing the documents needed for your stay</h6>
                    <p>With your presence in Istanbul, our staff will work with you at all stages of your appointment, filing and submitting them to the Migration Office on a designated date.</p>

                    <h6> Get a Residence</h6>
                    <p>All your family members will be posted to your home address within one to four weeks of your stay.</p>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.En.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/En/service/service1.blade.php ENDPATH**/ ?>