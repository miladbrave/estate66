<?php $__env->startSection('content'); ?>

    <div class="card-columns">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card bg-black">
            <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"><img class="card-img-top img-fluid" src="<?php echo e(asset($pro->photos[0]->path)); ?>" alt="Card image">
            <div class="card-body">
                <h6 class="card-title"><?php echo e($pro->title); ?></h6>
            </div></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>