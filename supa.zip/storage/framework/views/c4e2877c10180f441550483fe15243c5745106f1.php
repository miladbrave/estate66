<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/back/css/dropzone.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content" id="app">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title pull-right">ویرایش محصول <?php echo e($product->title); ?></h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form method="post" action="<?php echo e(route('product.update',$product->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group">
                                <label for="title">نام</label>
                                <input type="text" name="name" class="form-control"
                                       id="title" value="<?php echo e($product->title); ?>">
                            </div>
                            <div class="form-group">
                                <label for="slug">نام مستعار</label>
                                <input type="text" name="slug" class="form-control"
                                       id="slug" value="<?php echo e($product->slug); ?>">
                            </div>
                            <attribute-component :product="<?php echo e($product); ?>"></attribute-component>

                            <div class="form-group">
                                <label>قیمت محصول</label>
                                <input type="number" name="price" class="form-control"
                                       value="<?php echo e($product->price); ?>">
                            </div>
                            <div class="form-group">
                                <label>تخفیف</label>
                                <input type="number" name="dis_price" class="form-control"
                                       value="<?php echo e($product->dis_price); ?>">
                            </div>
                            <div class="form-group">
                                <label>توضیحات</label>
                                <textarea id="textareaDes" name="des" class="ckeditor form-control"><?php echo e($product->description); ?> </textarea>
                            </div>
                            <div class="form-group">
                                <label >نام شهر</label>
                                <input type="text" name="city" class="form-control"
                                       value="<?php echo e($product->country); ?>">
                            </div>
                            <div class="form-group">
                                <label >نام منطقه</label>
                                <input type="text" name="zone" class="form-control"
                                       value="<?php echo e($product->zone); ?>">
                            </div>
                            <div class="form-group">
                                <label>عنوان سئو</label>
                                <input type="text" name="meta_title" class="form-control"
                                       value="<?php echo e($product->title); ?>">
                            </div>
                            <div class="form-group">
                                <label>توضیحات سئو</label>
                                <textarea type="text" name="meta_desc" class="form-control"><?php echo e($product->meta_des); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>کلمات کلیدی سئو</label>
                                <input type="text" name="meta_keywords" class="form-control"
                                       value="<?php echo e($product->meta_keywords); ?>">
                            </div>
                            <div class="form-group">
                                <label>وضعیت نشر</label><br>
                                <input type="radio" name="status" value="0" checked><span>نشر</span>
                                <input type="radio" name="status" value="1" style="margin-left: 5%"><span>عدم نشر</span>
                            </div>
                            <div class="form-group">
                                <label for="photo">تصویر</label>
                                <input type="hidden" name="photo_id[]" id="product-photo">
                                <div id="photo" class="dropzone"></div>
                                <div class="row">
                                    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-3" id="photo_<?php echo e($photo->id); ?>">
                                            <img class="img-responsive" src="<?php echo e(asset( $photo->path)); ?>" alt="image">
                                            <button type="button" class="btn btn-danger" onclick="removeImages(<?php echo e($photo->id); ?>)">حذف
                                            </button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label>en</label>
                                <input type="checkbox" name="check" class="en">
                                <label>ara</label>
                                <input type="checkbox" name="check" class="tu">
                                <label>fra</label>
                                <input type="checkbox" name="check" class="tu">
                            </div>

                            <hr class="line">
                            
                            <strong style="text-align: center;margin-right: 50%;color: red">English</strong>

                            <hr class="line">

                            <div class="form-group">
                                <label>title</label>
                                <input type="text" name="entitle" class="form-control"
                                       value="<?php echo e($product->entitle); ?>">
                            </div>
                            <div class="form-group">
                                <label >slug</label>
                                <input type="text" name="enslug" class="form-control"
                                       value="<?php echo e($product->enslug); ?>">
                            </div>
                            <div class="form-group">
                                <label >Description</label>
                                <input type="text" name="endes" class="form-control"
                                       value="<?php echo e($product->endes); ?>">
                            </div>
                            <div class="form-group">
                                <label >city</label>
                                <input type="text" name="encity" class="form-control"
                                       value="<?php echo e($product->encountry); ?>">
                            </div>
                            <div class="form-group">
                                <label >نام منطقه</label>
                                <input type="text" name="enzone" class="form-control"
                                       value="<?php echo e($product->enzone); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_title</label>
                                <input type="text" name="enmeta_title" class="form-control"
                                       value="<?php echo e($product->en_seo_title); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_des</label>
                                <textarea type="text" name="enmeta_desc" class="form-control"
                                          value="<?php echo e($product->en_seo_des); ?>"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Seo_keywords</label>
                                <input type="text" name="enmeta_keywords" class="form-control"
                                       value="<?php echo e($product->en_seo_keywords); ?>">
                            </div>
                            <hr class="line">

                            
                            <strong style="text-align: center;margin-right: 50%;color: red">Arabic</strong>
                            <hr class="line">

                            <div class="form-group">
                                <label>title</label>
                                <input type="text" name="aratitle" class="form-control"
                                       value="<?php echo e($product->aratitle); ?>">
                            </div>
                            <div class="form-group">
                                <label >slag</label>
                                <input type="text" name="araslug" class="form-control"
                                       value="<?php echo e($product->araslug); ?>">
                            </div>
                            <div class="form-group">
                                <label >description</label>
                                <input type="text" name="arades" class="form-control"
                                       value="<?php echo e($product->arades); ?>">
                            </div>
                            <div class="form-group">
                                <label >city</label>
                                <input type="text" name="aracity" class="form-control"
                                       value="<?php echo e($product->aracountry); ?>">
                            </div>
                            <div class="form-group">
                                <label >نام منطقه</label>
                                <input type="text" araname="zone" class="form-control"
                                       value="<?php echo e($product->arazone); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_title</label>
                                <input type="text" name="arameta_title" class="form-control"
                                       value="<?php echo e($product->ara_seo_title); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_des</label>
                                <textarea type="text" name="arameta_desc" class="form-control"
                                          value="<?php echo e($product->ara_seo_des); ?>"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Seo_keywords</label>
                                <input type="text" name="arameta_keywords" class="form-control"
                                       value="<?php echo e($product->ara_seo_keywords); ?>">
                            </div>
                            <hr class="line">

                            
                            <strong style="text-align: center;margin-right: 50%;color: red">France</strong>
                            <hr class="line">

                            <div class="form-group">
                                <label>title</label>
                                <input type="text" name="fratitle" class="form-control"
                                       value="<?php echo e($product->fratitle); ?>">
                            </div>
                            <div class="form-group">
                                <label >slug</label>
                                <input type="text" name="fraslug" class="form-control"
                                       value="<?php echo e($product->fraslug); ?>">
                            </div>
                            <div class="form-group">
                                <label >description</label>
                                <input type="text" name="frades" class="form-control"
                                       value="<?php echo e($product->frades); ?>">
                            </div>
                            <div class="form-group">
                                <label >city</label>
                                <input type="text" name="fracity" class="form-control"
                                       value="<?php echo e($product->fracountry); ?>">
                            </div>
                            <div class="form-group">
                                <label >نام منطقه</label>
                                <input type="text" name="farzone" class="form-control"
                                       value="<?php echo e($product->farzone); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_title</label>
                                <input type="text" name="frameta_title" class="form-control"
                                       value="<?php echo e($product->fra_seo_title); ?>">
                            </div>
                            <div class="form-group">
                                <label>Seo_des</label>
                                <textarea type="text" name="frameta_desc" class="form-control"
                                          value="<?php echo e($product->fra_seo_des); ?>"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Seo_keywords</label>
                                <input type="text" name="frameta_keywords" class="form-control"
                                       value="<?php echo e($product->fra_seo_keywords); ?>">
                            </div>

                            <button type="submit" onclick="productGallery()" class="btn btn-success pull-left">ذخیره
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-vue'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('/back/js/dropzone.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back/ckeditor/ckeditor.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/back/js/backSelf.js')); ?>"></script>


    <script>
        Dropzone.autoDiscover = false;
        var photosGallery = []
        var photo = [].concat(<?php echo e($product->photos->pluck('id')); ?>)
        var drop = new Dropzone('#photo', {
            addRemoveLinks: true,
            url: "<?php echo e(route('photos.store')); ?>",
            sending: function (file, xhr, formData) {
                formData.append("_token", "<?php echo e(csrf_token()); ?>")
            },
            success: function (file, response) {
                photosGallery.push(response.photo_id)
            }
        });
        productGallery = function () {
                document.getElementById('product-photo').value = photosGallery.concat(photo)
        }
        CKEDITOR.replace('textareaDes', {
            customConfig: 'config.js',
            language: 'fa',
            toolbar: 'simple',
            removePlugins: 'cloudservices , easyimage'
        })
        removeImages = function (id) {
            var index = photo.indexOf(id)
            photo.splice(index , 1);
            document.getElementById('photo_' + id).remove();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SETUPPROG\WampServer.3.1.9.x64\www\supa\resources\views/backend/product/edit.blade.php ENDPATH**/ ?>