<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('/med/s1.jpg')); ?>" width="100%" height="350px" alt="" style="z-index: 1;position: relative">
    <div class="ser1">
        <div class="container" style="background-color: #f2f2e7">
            <div class="row">
                <div class="col-md-5">
                    <img src="<?php echo e(asset('/med/logo.png')); ?>" width="65%" height="auto" alt="" style="z-index: 1;position: relative"><br>
                </div>
                <div class="col-md-6">
                    <h5>Le processus d'achat du début à la fin</h5>

                    <h6>Voyager en Turquie et visiter des maisons</h6>
                    <p>Faites-nous savoir à votre arrivée en Turquie après avoir obtenu les informations nécessaires et préparé votre voyage en Turquie. Notre personnel vous accueillera à l'aéroport et vous fournira un hôtel 5 étoiles. Votre séjour de 4 jours à l'hôtel sera payé par nous et après une journée de repos, le processus de visite à domicile commence.</p>

                    <h6>Transfert d'argent et réception de documents</h6>
                    <p> Après avoir choisi votre maison préférée, nous transférerons votre argent (si vous en avez besoin) d'Iran. Après avoir complété et transféré votre argent, l'obtention de votre document personnel se fera en un seul jour ouvrable</p>

                    <h6>Eau, électricité, gaz et appareils électroménagers</h6>
                    <p>Le lendemain de la réception du document, le processus d'enregistrement et d'enregistrement de votre eau, électricité, maison de gaz et votre nom commencera avec notre personnel. Cette phase dure un à trois jours. De plus, si vous décidez d'acheter des appareils électroménagers, notre personnel vous aidera.</p>

                    <h6>Prendre le temps et préparer les documents nécessaires à votre séjour</h6>
                    <p>Grâce à votre présence à Istanbul, notre personnel travaillera avec vous à toutes les étapes de votre nomination, les classant et les soumettant au bureau des migrations à une date désignée.</p>

                    <h6>Obtenez une résidence</h6>
                    <p>Tous les membres de votre famille seront affichés à votre domicile dans les 1 à 4 semaines suivant votre séjour.</p>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.Fra.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/Fra/service/service1.blade.php ENDPATH**/ ?>