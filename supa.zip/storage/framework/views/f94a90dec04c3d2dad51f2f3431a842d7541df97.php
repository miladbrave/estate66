<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('/med/h1.jpg')); ?>" width="100%" height="300px" alt="" style="z-index: 1;position: relative;">

    <div class="product" style="margin-top: 5%">
        <div class="container">
            <div class="row">
                <div class="col-md-12 offset-md-0" style="margin-bottom: 1%">
                    <div id="gallery">
                        <div id="panel">
                            <img id="largeImage" src="<?php echo e(asset($product->photos[0]->path)); ?>" alt=".."
                                 style="width: 100%;height: 450px">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="column" style="margin: 1px">
                            <div id="thumbs">
                                <img src="<?php echo e(asset($photo->path)); ?>" style="width:100%;height: 100px;"
                                     alt="1st image description"/>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-6 attribute">
                    <ul>
                        <li><h4> <?php echo e($product->title); ?></h4></li>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <li><b>کد : </b><?php echo e($product->sku); ?></li>
                                <?php $__currentLoopData = $product->attributevalue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($attribute->attributeGroup->title == "متراژ"): ?>
                                        <li><b>متراژ :<?php echo e($attribute->title); ?></b></li>
                                    <?php endif; ?>
                                    <?php if($attribute->attributeGroup->title == "اتاق خواب"): ?>
                                        <li><b> تعداد اتاق :<?php echo e($attribute->title); ?></b></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-md-6">
                                <li><b>شهر : </b><?php echo e($product->fracountry); ?></li>
                            </div>
                        </div>
                    </ul>
                    <hr>
                    <div class="price">
                        <div class="row">
                            <?php if($product->dis_price): ?>
                                <div class="col-md-7"><h4
                                        style="text-align: right;direction: rtl;color: red"><?php echo e($product->dis_price); ?>

                                        تومان </h4></div>
                                <div class="col-md-5">
                                    <h4 style="text-align: right;direction: rtl;">
                                        <del><?php echo e($product->price); ?> تومان</del>
                                    </h4>
                                </div>
                            <?php else: ?>
                                <div class="col-md-10"><h4
                                        style="text-align: right;direction: rtl"><?php echo e($product->price); ?>

                                        تومان </h4></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <hr class="line">
        <div class="container" style="margin-bottom: 5%">
            <div class="characters">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#home">مشخصات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu1">توضیحات</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="home" class="container tab-pane active"><br>
                        <table class="table table-striped">
                            <tbody>
                            <?php $__currentLoopData = $product->attributevalue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($attribute->attributeGroup->fratitle); ?></td>
                                    <td><?php echo e($attribute->fratitle); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div id="menu1" class="container tab-pane fade"><br>
                        <h5><?php echo $product->fradescription; ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.En.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/En/projects/pro-self.blade.php ENDPATH**/ ?>