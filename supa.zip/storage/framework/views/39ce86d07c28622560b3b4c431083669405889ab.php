<?php $__env->startSection('content'); ?>
    <div class="contact">
        <div class="row" style="margin: 3%">
            <div class="col-md-6">
                <div class="fluid-wrapper">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1570.715724166662!2d46.36711565803346!3d38.06033210679803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzjCsDAzJzM3LjIiTiA0NsKwMjInMDUuNiJF!5e0!3m2!1sen!2s!4v1571555288758!5m2!1sen!2s"
                            width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
                <div class="info">
                    <div class="row">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <strong>A108 Adam Street,New York, NY 535022</strong>
                    </div>
                    <div class="row">
                        <i class="fa fa-envelope fa-2x"></i>
                        <strong>info@example.com</strong>
                    </div>

                    <div class="row">
                        <i class="fa fa-phone fa-2x"></i>
                        <strong>+1 5589 55488 55s</strong>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-5">
                <div class="form">
                    <form action="/action_page.php">
                        <div class="row">
                            <div class="col-25">
                                <label for="fname">First Name</label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="fname" name="firstname" placeholder="Your name..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="lname">Last Name</label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="lname" name="lastname" placeholder="Your last name..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="country">Topic</label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="lname" name="lastname" placeholder="Your Topic">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="subject">Subject</label>
                            </div>
                            <div class="col-75">
                                <textarea id="subject" name="subject" placeholder="Write something.."
                                          style="height:200px"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <input type="submit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/contactus.blade.php ENDPATH**/ ?>