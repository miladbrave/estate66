<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title"> ایجاد ویژگی</h3>
            </div>
            <?php if(Session::has('att_create')): ?>
                <div class="alert alert-danger">
                    <div><?php echo e(session('att_create')); ?></div>
                </div>
            <?php endif; ?>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form method="post" action="<?php echo e(route('attribute.store')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="name">عنوان</label>
                                <input type="text" name="name" class="form-control"
                                    required    placeholder="عنوان ویژگی را وارد کنید.. " id="name">
                            </div>
                            <div class="form-group">
                                <label for="name">name</label>
                                <input type="text" name="enname" class="form-control" required placeholder="عنوان دسته بندی را وارد کنید...">
                            </div>
                            <div class="form-group">
                                <label for="name">الاسم</label>
                                <input type="text" name="araname" class="form-control" required placeholder="عنوان دسته بندی را وارد کنید...">
                            </div>
                            <div class="form-group">
                                <label for="name">Nom</label>
                                <input type="text" name="franame" class="form-control" required placeholder="عنوان دسته بندی را وارد کنید...">
                            </div>
                            <div class="form-group">
                                <label for="type">نوع</label>
                                <select name="type" id="type" class="form-control">
                                    <option value="selected">لیست تکی</option>
                                    <option value="multi">لیست چندتایی</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success pull-left">ذخیره</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SETUPPROG\WampServer.3.1.9.x64\www\supa\resources\views/backend/attribute/create.blade.php ENDPATH**/ ?>