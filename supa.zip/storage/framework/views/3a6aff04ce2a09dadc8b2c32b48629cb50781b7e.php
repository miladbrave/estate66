<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title"> ویرایش دسته ها: <?php echo e($categories->name); ?></h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form method="post" action="<?php echo e(route('category.update',$categories)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group">
                                <label for="name">نام</label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($categories->name); ?>"
                                       id="name">
                            </div>
                            <div class="form-group">
                                <label for="meta_title">عنوان</label>
                                <input type="text" name="meta_title" class="form-control"
                                       value="<?php echo e($categories->meta_title); ?>" id="meta_title">
                            </div>
                            <div class="form-group">
                                <label for="meta_desc">توضیحات</label>
                                <textarea name="meta_desc" class="form-control"
                                          id="meta_desc"><?php echo e($categories->meta_des); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="meta_keywords">کلمات کلیدی</label>
                                <input type="text" name="meta_keywords" class="form-control"
                                       value="<?php echo e($categories->meta_keywords); ?>" id="meta_keywords">
                            </div>

                            <button type="submit" class="btn btn-success pull-left">ذخیره</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>