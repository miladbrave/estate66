<?php if(isset($select_cat)): ?>
    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($sub->id); ?>"
                <?php if($categories->parent_id == $sub->id): ?> selected <?php endif; ?>><?php echo e(str_repeat('--', $level)); ?> <?php echo e($sub->name); ?></option>
        <?php if(count($sub->childRecursive)>0): ?>
            <?php echo $__env->make('admin.partial.category',['cat' => $sub->childRecursive , 'level' => $level+1, 'select_cat'=>$categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($sub->id); ?>"><?php echo e(str_repeat('--', $level)); ?> <?php echo e($sub->name); ?></option>
        <?php if(count($sub->childRecursive)>0): ?>
            <?php echo $__env->make('admin.partial.category',['cat' => $sub->childRecursive , 'level' => $level+1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/partial/category.blade.php ENDPATH**/ ?>