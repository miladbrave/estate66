<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title"> ایجاد مقدار ویژگی</h3>
            </div>
            
            
            
            
            
            <div class="box-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form method="post" action="<?php echo e(route('attributevalue.store')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="att-group">انتخاب ویژگی</label>
                                <select name="att-group" id="att-group" class="form-control">
                                    <option value="">انتخاب کنید</option>
                                    <?php $__currentLoopData = $attvalue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($attv->id); ?>"><?php echo e($attv->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="title">عنوان</label>
                                <input type="text" name="title" class="form-control"
                                       placeholder="عنوان مقدار ویژگی را وارد کنید.. " id="title">
                            </div>

                            <button type="submit" class="btn btn-success pull-left">ذخیره</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/attributevalue/create.blade.php ENDPATH**/ ?>