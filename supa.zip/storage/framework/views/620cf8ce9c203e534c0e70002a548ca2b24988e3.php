<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('/med/aboutus.jpg')); ?>" width="100%" height="450px" alt="" style="z-index: 1;position: relative">

    <div class="ser1">
        <div class="container" style="background-color: #f2f2e7">
            <div class="row">
                <div class="col-md-5">
                    <img src="<?php echo e(asset('/med/logo.png')); ?>" width="65%" height="auto" alt="" style="z-index: 1;position: relative"><br>
                </div>
                <div class="col-md-6">
                    <p style="font-size: 22px">شرکت....</p>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/about.blade.php ENDPATH**/ ?>