<?php $__env->startSection('content'); ?>
    <div class="gal2">
        <div class="gal">
            <div class="row">
                <div class="col-md-12 d-flex justify-content-center mb-5">
                    <button type="button" class="btn btn-dark waves-effect filter" data-rel="all"
                            style="margin-left: 1%">All
                    </button>
                    <button type="button" class="btn btn-danger waves-effect filter" data-rel="1"
                            style="margin-left: 1%">
                        Turkey
                    </button>
                    <button type="button" class="btn btn-danger waves-effect filter" data-rel="2"
                            style="margin-left: 1%">Kıbrıs
                    </button>
                    <button type="button" class="btn btn-danger waves-effect filter" data-rel="3"
                            style="margin-left: 1%">
                        Iran
                    </button>
                </div>
            </div>
            <div class="gallery" id="gallery">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-auto pics animation all <?php echo e($pro->country); ?>">
                        <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"> <img class="g-img" src="<?php echo e(asset($pro->photos[0]->path)); ?>"
                                          alt="Card image cap"></a>
                        <h6 class="content2"><?php echo e($pro->title); ?></h6>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="demo">
        <h4 style="text-align: center">Our Last Projects</h4>
        <div id="owl-demo2">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"><div class="item"><img src="<?php echo e(asset($pro->photos[0]->path)); ?>" alt="Owl Image"></div></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/project.blade.php ENDPATH**/ ?>