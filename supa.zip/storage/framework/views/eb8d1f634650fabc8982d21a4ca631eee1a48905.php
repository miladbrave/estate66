<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">مقادیر ویژگی ها</h3>
                <div class="box-tools pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('attributevalue.create')); ?>">جدید</a>
                </div>
            </div>





            <div class="box-body">
                <div class="table-responsive">
                    <table class="table no-margin">
                        <thead>
                        <tr>
                            <th class="text-center">عملیات</th>
                            <th class="text-center">ویژگی</th>
                            <th class="text-center">عنوان</th>
                            <th class="text-center">شناسه</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $attvalue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <form method="post" action="<?php echo e(route('attribute.destroy',$attval->id)); ?>" style="display: inline">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('Delete')); ?>

                                        <button class="btn btn-danger">حذف</button>
                                    </form>
                                    <a href="<?php echo e(route('attributevalue.edit',$attval->id)); ?>" class="btn btn-warning">ویرایش</a>
                                </td>
                                <td class="text-center"> <?php echo e($attval->attributeGroup->title); ?></td>
                                <td class="text-center"><?php echo e($attval->title); ?></td>
                                <td class="text-center"><?php echo e($attval->id); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/attributevalue/index.blade.php ENDPATH**/ ?>