<?php if(count($errors)>0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/partial/form-error.blade.php ENDPATH**/ ?>