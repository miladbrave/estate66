<!DOCTYPE html>
<html lang="en">

<head>
    <title>HomeLand</title>
    <link href="<?php echo e(asset('/agency/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/agency/css/agency.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/agency/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <link href="<?php echo e(asset('/agency/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/owl.theme.default.min')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/second.css')); ?>">

</head>

<body>

<nav class="navbar fixed-top" id="mainNav">
    <div class="container"><a id="navbar-brand" href="#"><img id="header" src="<?php echo e(asset('/med/logo2.png')); ?>" alt=""></a>
    </div>
</nav>

<div id="owl-demo">
    <div class="item"><img src="<?php echo e(asset('/med/portfolio/p1.jpg')); ?>" alt="Owl Image"></div>
    <div class="item"><img src="<?php echo e(asset('/med/portfolio/p2.jpg')); ?>" alt="Owl Image"></div>
    <div class="item"><img src="<?php echo e(asset('/med/portfolio/p6.jpg')); ?>" alt="Owl Image"></div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
                aria-label="Toggle navigation">
            Menu
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#">درباره ما</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#">خدمات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#">گالری</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#">پروژه</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#">خانه</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div id="card">
    <div class="card-columns">
        <a href="#"><div class="card">
            <img class="card-img-top" src="<?php echo e(asset('med/portfolio/p4.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h5 class="card-title">خانه یک</h5>
                <p class="card-text">این خانه بزرگ . شیک و بسیار گران قیمت است</p>
            </div>
        </div></a>
        <a href="#"> <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('med/portfolio/p5.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h5 class="card-title">خانه دو</h5>
                <p class="card-text">این خانه بزرگ . شیک و بسیار گران قیمت است</p>
            </div>
        </div></a>
        <a href="#"> <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('med/portfolio/p6.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h5 class="card-title">خانه سوم</h5>
                <p class="card-text">این خانه بزرگ . شیک و بسیار گران قیمت است</p>
            </div>
        </div></a>
        <a href="#"> <div class="card">
            <img class="card-img-top" src="<?php echo e(asset('med/portfolio/p7.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h5 class="card-title">خانه چهارم</h5>
                <p class="card-text">این خانه بزرگ . شیک و بسیار گران قیمت است</p>
            </div>
        </div></a>
    </div>
</div>

<div class="container" style="margin-top: 5%;">
    <div class="row text-center info">
        <div class="col-md-3">
                 <span class="fa-stack fa-4x">
                    <i class="fas fa-circle fa-stack-2x text-primary"></i>
                    <i class="fas fa-home fa-stack-1x fa-inverse"></i>
                 </span>
            <h4 class="service-heading">اطلاعات بازار مسکن</h4>
            <p class="text-muted">این روز ها در بازار مسکن نوسانات زیادی وجود دارد که این امر باعث سردرگمی مشتریان میشود.لذا ما بر آنیم که...</p>
        </div>
        <div class="col-md-3">
                 <span class="fa-stack fa-4x">
                     <i class="fas fa-circle fa-stack-2x text-primary"></i>
                     <i class="fas fa-dollar fa-stack-1x fa-inverse"></i>
                      </span>
            <h4 class="service-heading">قیمت خانه شما</h4>
            <p  class="text-muted">قیمت خانه به شاخص های مختلفی بستگی دارداز جمله موقعیت مکانی و مرغوبیت زمین..</p>
        </div>
        <div class="col-md-3">
                 <span class="fa-stack fa-4x">
                  <i class="fas fa-circle fa-stack-2x text-primary"></i>
                  <i class="fas fa-handshake-o fa-stack-1x fa-inverse"></i>
                  </span>
            <h4 class="service-heading">سپردن ملک</h4>
            <p class="text-muted">شما می توانیم با خیال راحت ملکتان را د ر اختیار ما قرار داده تا...</p>
        </div>
        <div class="col-md-3">
                 <span class="fa-stack fa-4x">
                     <i class="fas fa-circle fa-stack-2x text-primary"></i>
                     <i class="fas fa-cog fa-stack-1x fa-inverse"></i>
                 </span>
            <h4 class="service-heading">اطلاعات فنی</h4>
            <p class="text-muted">آگاهی از وضیت بازار و....</p>
        </div>
    </div>
</div>

<div class="gal" style="margin-top: 5%">
    <h1>ما را با پروژه های شیک در کشور های مختلف همراهی کنید</h1>

    <div class="row">
        <div class="col-md-12 d-flex justify-content-center mb-5">
            <button type="button" class="btn btn-outline-black waves-effect filter" data-rel="all">All</button>
            <button type="button" class="btn btn-outline-black waves-effect filter" data-rel="1">
                Turkey
            </button>
            <button type="button" class="btn btn-outline-black waves-effect filter" data-rel="2">Kıbrıs
            </button>
            <button type="button" class="btn btn-outline-black waves-effect filter" data-rel="3">
                Iran
            </button>
        </div>
    </div>
    <div class="gallery" id="gallery">
        <div class="mb-3 pics animation all 2">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p1.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>
        </div>
        <div class="mb-3 pics animation all 1">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p2.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>

        </div>
        <div class="mb-3 pics animation all 1">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p4.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>

        </div>
        <div class="mb-3 pics animation all 2">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p5.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>

        </div>
        <div class="mb-3 pics animation all 2">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p6.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>

        </div>
        <div class="mb-3 pics animation all 3">
            <a href="#"> <img class="img-fluid" src="<?php echo e(asset('/med/portfolio/p7.jpg')); ?>"
                              alt="Card image cap">
                <h6 class="content">دوبلکس</h6></a>

        </div>
    </div>
</div>

<div class="middle">
    <div class="row">
        <div class="col-md-3" style="margin-bottom: 5%">
            <h3 style="margin-bottom: 3%">Questions</h3>
            <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#demo">How Can I Buy new House?</button>
            <div id="demo" class="collapse show">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </div>
            <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#demo2" style="margin-top: 5%">What is your new project?</button>
            <div id="demo2" class="collapse show" style="margin-bottom: 5%">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </div>
        </div>
        <div class="col-md-6">
            <div class="container">
                <h2>Information</h2>
                <br>
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#home">İkamet ve Yurttaşlık</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu1">Temiz Kağıdı</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu2">Taşınma</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu3">Satın Alma İzni</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="home" class="container tab-pane active"><br>
                        <h3>HOME</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                            do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                            do eiusmod
                            tempor incididunt
                            <ut></ut>
                        </p>
                    </div>
                    <div id="menu1" class="container tab-pane fade"><br>
                        <h3>Menu 1</h3>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                            commodo consequat.</p>
                    </div>
                    <div id="menu2" class="container tab-pane fade"><br>
                        <h3>Menu 2</h3>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                            laudantium, totam rem aperiam.</p>
                    </div>
                    <div id="menu3" class="container tab-pane fade"><br>
                        <h3>Menu 3</h3>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                            laudantium, totam rem aperiam.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <h2>Duyurular</h2>
            <br>
            <p style="background-color: rgba(13,163,255,0.62)">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                sed do eiusmod tempor incididunt utLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                eiusmod tempor incididunt ut
                labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut
                labore et dolore magna aliqua.
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua
                Lorem ipsum dolor sit amet, consectetur adipisicing elita</p>
        </div>
    </div>
</div>

<hr style="width: 80%;">
<div class="demo">
    <h4 style="text-align: center">Our Last Projects</h4>
    <div id="owl-demo2">
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p1.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p2.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p6.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p4.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p5.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p7.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p6.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p4.jpg')); ?>" alt="Owl Image"></div>
        <div class="item"><img src="<?php echo e(asset('/med/portfolio/p5.jpg')); ?>" alt="Owl Image"></div>
    </div>
</div>


<div class="foot">
    <div class="row">
        <div class="col-md-4">
            <h4>Homeland</h4>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut
                labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut

            </p>
        </div>
        <div class="col-md-5">
            <img id="footer-image" src="<?php echo e(asset('/med/logo2.png')); ?>" alt=""><br>
            <a href="#"><img id="footer-f" src="<?php echo e(asset('/med/f.png')); ?>" alt="" style="margin-left: 18%"></a>
            <a href="#"><img id="footer-f" src="<?php echo e(asset('/med/t.png')); ?>" alt="" style="margin-left: 5%"></a>
            <a href="#"><img id="footer-f" src="<?php echo e(asset('/med/i.png')); ?>" alt="" style="margin-left: 5%"></a>

        </div>
        <div class="col-md-3" style="margin-top: 3%">
            <div class="container">
            <h6 style="color: #000000">Adres:</h6>
            <h7 style="color: #fe0000">Kubbeli Çeşme Sk. Uğur Mumcu Bulv. Lotus Tower Apt. Kat:1 No:1 Girne/KKTC</h7>
            <hr>
            <h6 style="color: black">Telefon(Ofis):</h6>
            <h7 style="color: #fe0000">+90(533) 825 3636</h7>
            <hr>
            <h6 style="color: black">Satış Temsilcisi:</h6>
            <h7 style="color: #fe0000">+90(533) 822 3636</h7>
            <hr>
            <h6 style="color: black">E-mail:</h6>
            <h7 style="color: #fe0000">info@aladaginsaatkibris.com</h7>
            </div>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('/agency/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/agency/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/agency/js/agency.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('/js/self2.js')); ?>"></script>
<script src="<?php echo e(asset('/js/self3.js')); ?>"></script>

<script>
    window.onscroll = function () {
        scrollFunction()
    };
    document.getElementById('header').style.width = "20%";

    $(document).ready(function () {
        $("#owl-demo2").owlCarousel()({
            navigation: true
        });
    });
</script>

</body>

</html>
<?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/template/layout/master.blade.php ENDPATH**/ ?>