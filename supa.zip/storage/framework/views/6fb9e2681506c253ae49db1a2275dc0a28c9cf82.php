<?php $__env->startSection('content'); ?>
    <div>
    <img src="<?php echo e(asset('/med/t3.jpg')); ?>" width="100%" height="600px" alt="" style="z-index: 1;">
    </div>
    <div class="search">
        <form>
            <select name="pets" id="pet-select">
                <option value="">قیمت</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <select name="pets2" id="pet-select">
                <option value="">اتاق خواب</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <select name="pets3" id="pet-select">
                <option value="">سروریس بهداشتی</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <select name="pets4" id="pet-select">
                <option value="">نوع مالکیت</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <select name="pets5" id="pet-select">
                <option value="">موقیت مکانی</option>
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
            </select>
            <button class="btn btn-dark btn-sm" type="submit" name="submit">جستجو</button>
        </form>
    </div>

    <div class="f-proj wow fadeInUp slow">
        <div class="container" style="margin: 3%">
            <h4 style="text-align: center;margin: 3%" class="font-weight-bold">پروژه های محبوب</h4>
            <div class="card-deck">
                <div class="card ">
                    <a href="" class="text-decoration-none"><img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body ">
                       <h5 class="card-title">Card title</h5>
                        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to
                            additional content. This content is a little bit longer.</p>
                         </div></a>
                </div>
                <div class="card">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This card has supporting text below as a natural lead-in to additional
                            content.</p>
                    </div></a>
                </div>
                <div class="card">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                            additional content. This card has even longer content than the first to show that equal
                            height action.</p>
                    </div></a>
                </div>
            </div>
            <button type="button" href="#" class="btn btn-warning" style="margin-left: 45%;margin-top: 2%">املاک بیشتر</button>
        </div>
    </div>


    <section id="subscribe">
        <div class="container wow fadeInUp">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="subscribe-title">از کشور ترکیه چه می دانید؟</h3>
                    <a class="subscribe-btn" href="#">اطلاعات بیشتر</a>
                </div>
            </div>
        </div>
    </section>


    <div class="f-proj wow fadeInUp slow">
        <div class="container" style="margin: 3%">
            <h4 style="text-align: center;margin: 3%" class="font-weight-bold">فروش فوری</h4>
            <div class="card-deck">
                <div class="card ">
                    <a href="" class="text-decoration-none"><img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to
                                additional content. This content is a little bit longer.</p>
                        </div></a>
                </div>
                <div class="card">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This card has supporting text below as a natural lead-in to additional
                                content.</p>
                        </div></a>
                </div>
                <div class="card">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                                additional content. This card has even longer content than the first to show that equal
                                height action.</p>
                        </div></a>
                </div>
            </div>
            <button type="button" href="#" class="btn btn-warning" style="margin-left: 45%;margin-top: 2%">املاک بیشتر</button>
        </div>
    </div>

    <hr class="line">

    <div class="f-proj">
        <div class="container" style="margin: 3%">
            <h4 style="text-align: center;margin: 3%" class="font-weight-bold">سرمایه گذاری</h4>
            <div class="card-deck">
                <div class="card wow fadeInUp slow">
                    <a href="" class="text-decoration-none"><img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body ">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a longer card with supporting text below as a natural lead-in to
                                additional content. This content is a little bit longer.</p>
                        </div></a>
                </div>
                <div class="card wow fadeInDown slow">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This card has supporting text below as a natural lead-in to additional
                                content.</p>
                        </div></a>
                </div>
                <div class="card wow fadeInUp slow">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                                additional content. This card has even longer content than the first to show that equal
                                height action.</p>
                        </div></a>
                </div>
                <div class="card wow fadeInDown slow">
                    <a href="" class="text-decoration-none">  <img src="<?php echo e(asset('/med/rent.jpg')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                                additional content. This card has even longer content than the first to show that equal
                                height actio</p>
                        </div></a>
                </div>
            </div>
            <button type="button" href="#" class="btn btn-warning" style="margin-left: 45%;margin-top: 2%">املاک بیشتر</button>
        </div>
    </div>

    <hr class="line">

    <div class="middle">
        <div class="row">
            <div class="col-md-3 wow fadeInLeft slow" style="margin-bottom: 5%">
                <h3 style="margin-bottom: 3%">Questions</h3>
                <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#demo">How Can I Buy new House?</button>
                <div id="demo" class="collapse show">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </div>
                <button type="button" class="btn btn-success" data-toggle="collapse" data-target="#demo2" style="margin-top: 5%">What is your new project?</button>
                <div id="demo2" class="collapse show" style="margin-bottom: 5%">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </div>
            </div>
            <div class="col-md-6">
                <div class="container">
                    <h2>Information</h2>
                    <br>
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#home">İkamet ve Yurttaşlık</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#menu1">Temiz Kağıdı</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#menu2">Taşınma</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#menu3">Satın Alma İzni</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="home" class="container tab-pane active"><br>
                            <h3>HOME</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                                labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                                do eiusmod tempor incididunt ut
                                labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed
                                do eiusmod
                                tempor incididunt
                                <ut></ut>
                            </p>
                        </div>
                        <div id="menu1" class="container tab-pane fade"><br>
                            <h3>Menu 1</h3>
                            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.</p>
                        </div>
                        <div id="menu2" class="container tab-pane fade"><br>
                            <h3>Menu 2</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                                laudantium, totam rem aperiam.</p>
                        </div>
                        <div id="menu3" class="container tab-pane fade"><br>
                            <h3>Menu 3</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                                laudantium, totam rem aperiam.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 wow fadeInRight slow">
                <h2>Duyurular</h2>
                <br>
                <p style="background-color: rgba(13,163,255,0.62)">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor incididunt utLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                    eiusmod tempor incididunt ut
                    labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut
                    labore et dolore magna aliqua.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                    labore et dolore magna aliqua
                    Lorem ipsum dolor sit amet, consectetur adipisicing elita</p>
            </div>
        </div>
    </div>
    <hr class="line">
    <div class="demo">
        <h4 style="text-align: center">Our Last Projects</h4>
        <div id="owl-demo2">



            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t1.jpg')); ?>" alt=""></div></a>
            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t2.jpg')); ?>" alt=""></div></a>
            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t3.jpg')); ?>" alt=""></div></a>
            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t1.jpg')); ?>" alt=""></div></a>
            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t2.jpg')); ?>" alt=""></div></a>
            <a href="#"><div class="item"><img src="<?php echo e(asset('/med/t3.jpg')); ?>" alt=""></div></a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend\En\index.blade.php ENDPATH**/ ?>