<?php $__env->startSection('content'); ?>
    <div class="head">
    <img  src="<?php echo e(asset('/med/contact-banner.jpg')); ?>" width="100%" height="450px" alt="" style="z-index: 1;position: relative">

    </div>
    <div class="contact wow fadeInUp slow">
        <h5 style="text-align: center">ابقى على اتصال معنا</h5>
        <hr class="line">
        <div class="row" style="margin: 1%;position: relative">
            <div class="col-md-5 wow fadeInLeft slow">
                <div class="info">
                    <i class="fa fa-map-marker fa-1x"></i>
                    <h5> العنوان :</h5>
                    <hr class="line">
                    <h6>ایران , تبریز..</h6>

                    <i class="fa fa-phone fa-1x"></i>
                    <h5> مكالمة هاتفية :</h5>
                    <hr class="line">
                    <h6>98123-4567-002+</h6>

                    <i class="fa fa-envelope fa-1x"></i>
                    <h5> البريد الإلكتروني :</h5>
                    <hr class="line">
                    <h6>example@gmail.com</h6>
                </div>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-6 wow fadeInRight slow">
                <div class="form">
                    <form action="/action_page.php">
                        <div class="row">
                            <div class="col-25">
                                <label for="fname"></label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="fname" name="firstname" placeholder="الاسم الاول..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="lname"></label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="lname" name="lastname" placeholder="الكنية..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="country"></label>
                            </div>
                            <div class="col-75">
                                <input type="text" id="lname" name="lastname" placeholder="موضوع..">

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-25">
                                <label for="subject"></label>
                            </div>
                            <div class="col-75">
                                <textarea id="subject" name="subject" placeholder="شرح.."
                                          style="height:200px"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <input class="btn btn-sm btn-primary offset-3" type="submit" value="إرسال">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12 offset-md-0 wow fadeInLeft slow" >
            <div class="fluid-wrapper" style="border: 3px gray solid">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1570.715724166662!2d46.36711565803346!3d38.06033210679803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzjCsDAzJzM3LjIiTiA0NsKwMjInMDUuNiJF!5e0!3m2!1sen!2s!4v1571555288758!5m2!1sen!2s"
                        width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </div>
    </div>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.ara.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/ara/contact.blade.php ENDPATH**/ ?>