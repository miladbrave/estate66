<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('/med/h1.jpg')); ?>" width="100%" height="350px" alt="" style="z-index: 1;position: relative;">


    <div class="result" style="margin-top: 5%;">
        <div class="container">
            <h2 style="float: right;text-align: right">نتائج البحث</h2>
            <hr class="line" style="float: right;width: 100%;margin-right: 1%;margin-top:2%">
            <div class="row">
                <div class="card-columns">
                    <?php if($number): ?>
                        <?php $__currentLoopData = $number; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card wow fadeInUp slow">
                                <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"
                                   class="text-decoration-none"><img src="<?php echo e(asset($pro->photos[0]->path)); ?>" width="100%"
                                                                     height="200px" class="card-img-top" alt="...">
                                    <div class="card-body ">
                                        <h5 class="card-title"><?php echo e($pro->aratitle); ?></h5>
                                        <p class="card-text"><?php echo $pro->arades; ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if($rom): ?>
                        <?php $__currentLoopData = $rom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card wow fadeInUp slow">
                                <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"
                                   class="text-decoration-none"><img src="<?php echo e(asset($pro->photos[0]->path)); ?>" width="100%"
                                                                     height="200px" class="card-img-top" alt="...">
                                    <div class="card-body ">
                                        <h5 class="card-title"><?php echo e($pro->aratitle); ?></h5>
                                        <p class="card-text"><?php echo $pro->arades; ?>.</p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if($type): ?>
                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card wow fadeInUp slow">
                                <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"
                                   class="text-decoration-none"><img src="<?php echo e(asset($pro->photos[0]->path)); ?>" width="100%"
                                                                     height="200px" class="card-img-top" alt="...">
                                    <div class="card-body ">
                                        <h5 class="card-title"><?php echo e($pro->aratitle); ?></h5>
                                        <p class="card-text"><?php echo $pro->arades; ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if($locate): ?>
                        <?php $__currentLoopData = $locate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card wow fadeInUp slow">
                                <a href="<?php echo e(route('product.single',['slug' => $pro->slug])); ?>"
                                   class="text-decoration-none"><img src="<?php echo e(asset($pro->photos[0]->path)); ?>" width="100%"
                                                                     height="200px" class="card-img-top" alt="...">
                                    <div class="card-body ">
                                        <h5 class="card-title"><?php echo e($pro->aratitle); ?></h5>
                                        <p class="card-text"><?php echo $pro->arades; ?></p>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <?php if(!$number && !$rom && !$type && !$locate): ?>
                    <div>
                        <p style="text-align: right;direction: rtl;float: right">آسف ، لا توجد عناصر!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.ara.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/ara/search.blade.php ENDPATH**/ ?>