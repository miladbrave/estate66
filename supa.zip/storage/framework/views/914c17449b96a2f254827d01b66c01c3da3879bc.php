<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   <a  href="<?php echo e(route('dashboard')); ?>"><button type="button" class="btn btn-outline-danger float-right"  >ورود به پنل مدیریت </button>
                   </a>
                </div>
            </div>
            <img src="<?php echo e(asset('/med/logo.png')); ?>" width="100%" height="400px" alt="">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/home.blade.php ENDPATH**/ ?>