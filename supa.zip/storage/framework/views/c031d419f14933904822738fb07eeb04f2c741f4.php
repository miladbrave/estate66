<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title">ویژگی ها</h3>
                <div class="box-tools pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('attribute.create')); ?>">جدید</a>
                </div>
            </div>
            <?php if(Session::has('error_category')): ?>
                <div class="alert alert-danger">
                    <div><?php echo e(session('error_category')); ?></div>
                </div>
            <?php endif; ?>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table no-margin">
                        <thead>
                        <tr>
                            <th class="text-center">عملیات</th>
                            <th class="text-center">نوع</th>
                            <th class="text-center">عنوان</th>
                            <th class="text-center">شناسه</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $attributeGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <form method="post" action="<?php echo e(route('attribute.destroy',$att->id)); ?>" style="display: inline">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('Delete')); ?>

                                        <button class="btn btn-danger">حذف</button>
                                    </form>
                                    <a href="<?php echo e(route('attribute.edit',$att->id)); ?>" class="btn btn-warning">ویرایش</a>
                                </td>
                                <td class="text-center"> <?php echo e($att->type); ?></td>
                                <td class="text-center"><?php echo e($att->title); ?></td>
                                <td class="text-center"><?php echo e($att->id); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div style="margin-right: 40%">
            <?php echo e($attributeGroup->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SETUPPROG\WampServer.3.1.9.x64\www\supa\resources\views/backend/attribute/index.blade.php ENDPATH**/ ?>