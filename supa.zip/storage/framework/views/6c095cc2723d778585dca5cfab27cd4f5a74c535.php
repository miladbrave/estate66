<?php $__env->startSection('content'); ?>
    <img alt="" src="<?php echo e(asset('/med/h1.jpg')); ?>" width="100%" height="500px">

    <div class="card-columns">
        <div class="card bg-white">
            <img class="card-img-top img-fluid" src="<?php echo e(asset('/agency/img/team/1.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark img-fluid">
                <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title">John Doe</h4>
                    <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
                </div>
        </div>
        <div class="card bg-white">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark">
                <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/3.jpg')); ?>" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title">John Doe</h4>
                    <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-white">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/1.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-white">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/3.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-white">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/1.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-white">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/2.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
        <div class="card bg-dark">
            <img class="card-img-top" src="<?php echo e(asset('/agency/img/team/3.jpg')); ?>" alt="Card image">
            <div class="card-body">
                <h4 class="card-title">John Doe</h4>
                <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/products.blade.php ENDPATH**/ ?>