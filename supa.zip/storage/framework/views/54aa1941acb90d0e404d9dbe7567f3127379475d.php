<?php $__env->startSection('content'); ?>

    <img src="<?php echo e(asset('/med/s1.jpg')); ?>" width="100%" height="350px" alt="" style="z-index: 1;position: relative">
    <div class="ser1">
        <div class="container" style="background-color: #f2f2e7">
            <div class="row">
                <div class="col-md-5">
                    <img src="<?php echo e(asset('/med/logo.png')); ?>" width="65%" height="auto" alt="" style="z-index: 1;position: relative"><br>
                </div>
                <div class="col-md-6">
                    <h5>عملية الشراء من البداية إلى النهاية</h5>

                    <h6>السفر إلى تركيا وزيارة المنازل</h6>
                    <p>أخبرنا عند وصولك إلى تركيا بعد الحصول على المعلومات اللازمة وإعداد رحلتك إلى تركيا. سيرحب بك موظفونا في المطار وسيوفر لك فندق 5 نجوم. سيتم دفع إقامتك لمدة 4 أيام في الفندق من قبلنا وبعد يوم من الراحة ، تبدأ عملية الزيارة المنزلية.</p>

                    <h6>تحويل الأموال وإيصال المستند</h6>
                    <p>بعد اختيار منزلك المفضل ، سنحول أموالك (إذا كنت في حاجة إليها) من إيران إليك. بعد الانتهاء من تحويل أموالك وتحويلها ، سيتم الحصول على مستند منزلك في يوم عمل واحد فقط.</p>

                    <h6>المياه والكهرباء والغاز والأجهزة المنزلية</h6>
                    <p>ي اليوم التالي لاستلام المستند ، ستبدأ عملية تسجيل وتسجيل المياه والكهرباء والغاز في المنزل واسمك مع موظفينا. هذه المرحلة تستغرق من يوم إلى ثلاثة أيام. أيضًا ، إذا قررت شراء الأجهزة المنزلية ، فسيقوم موظفونا بمساعدتك.</p>

                    <h6>أخذ الوقت وإعداد المستندات المطلوبة لإقامتك</h6>
                    <p>مع وجودك في اسطنبول ، سيعمل موظفونا معك في جميع مراحل موعدك ، وتقديمهم وتقديمهم إلى مكتب الهجرة في الموعد المحدد.</p>

                    <h6>الحصول على الإقامة</h6>
                    <p>سيتم نشر جميع أفراد عائلتك على عنوان منزلك في غضون أسبوع إلى أربعة أسابيع من إقامتك.</p>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.ara.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/frontend/ara/service/service1.blade.php ENDPATH**/ ?>