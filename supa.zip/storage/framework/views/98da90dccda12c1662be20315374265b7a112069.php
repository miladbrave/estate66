<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="box-title pull-right">  تعیین ویژگی دسته بندی  <?php echo e($category->name); ?>  </h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form method="post" action="<?php echo e(route('saveSetting',$category->id)); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="att">ویژگی ها</label>
                                <select name="att[]" id="att" class="form-control" multiple>
                                    <?php $__currentLoopData = $attributeGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($attributeGroup->id); ?>" <?php if(in_array($attributeGroup->id,$category->attributeGroups->pluck('id')->toArray())): ?> selected <?php endif; ?>><?php echo e($attributeGroup->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success pull-left">ذخیره</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SOFTWARE\SOFTWARE\LEARNER\PHP\WampServer.3.1.9.x64\www\supa\resources\views/backend/category/indexSetting.blade.php ENDPATH**/ ?>