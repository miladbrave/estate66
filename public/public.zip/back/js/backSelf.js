// $('.en').click(function() {
//     if($(this).is(':checked')) {
//         $('<label>').text('name').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'name',
//             placeholder: 'Enter the title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('enslug').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'enslug',
//             placeholder: 'Enter the slug'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('endes').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control',
//             name: 'endes',
//             placeholder: 'description remove'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('enStitle').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'enStitle',
//             placeholder: 'seo_title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('enSdes').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'enSdes',
//             placeholder: 'seo_des'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('enSkeywords').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'enSkeywords',
//             placeholder: 'seo_keywords'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<hr>').attr({class: 'remove'}).appendTo('form')
//     }
//     else {
//         $('.remove').hide()
//     }
// });
//
// $('.tu').click(function() {
//     if($(this).is(':checked')) {
//         $('<label>').text('Ad').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove2',
//             name: 'Ad',
//             placeholder: 'Enter the title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('slug').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove2',
//             name: 'slag',
//             placeholder: 'Enter the slug'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('fiat').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'number',
//             class: 'form-control remove2',
//             name: 'fiat',
//             placeholder: 'fiat'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('indirim').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'numer',
//             class: 'form-control remove2',
//             name: 'indirim',
//             placeholder: 'indirim'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('açıklama').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control',
//             name: 'açıklama',
//             placeholder: 'açıklama remove2'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-title').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove2',
//             name: 'seo-title',
//             placeholder: 'seo-title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-des').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove2',
//             name: 'seo-des',
//             placeholder: 'seo-des'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-keywords').attr({class: 'remove2'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove2',
//             name: 'seo-keywords',
//             placeholder: 'seo-keywords'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove2',
//             }).appendTo('form'))
//
//         $('<hr>').attr({class: 'remove'}).appendTo('form')
//
//     }
//     else {
//         $('.remove2').remove()
//     }
// });
//
// $('.ar').click(function() {
//     if($(this).is(':checked')) {
//         $('<label>').text('name').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'name',
//             placeholder: 'Enter the title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('slug').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'slug',
//             placeholder: 'Enter the slug'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('price').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'price',
//             placeholder: 'Enter the price'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('dis_price').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'dis_price',
//             placeholder: 'dis_price'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('des').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control',
//             name: 'des',
//             placeholder: 'description remove'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-title').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'seo-title',
//             placeholder: 'seo-title'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-des').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'seo-des',
//             placeholder: 'seo-des'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//
//         $('<label>').text('seo-keywords').attr({class: 'remove'}).appendTo('form')
//         $('<input>').attr({
//             type: 'text',
//             class: 'form-control remove',
//             name: 'seo-keywords',
//             placeholder: 'seo-keywords'
//         }).appendTo(
//             $('<div>').attr({
//                 class: 'form-group remove',
//             }).appendTo('form'))
//     }
//     else {
//         $('.remove').remove()
//     }
// });
